package com.springMVC.controller;

import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

@Controller
public class MyController {
	
	@RequestMapping("/")
	public String home() {
		return "home";
	}
	
	@RequestMapping("/showform")
	public String show() {
		return "form";
	}
	
	@RequestMapping("/processform")
	public String process() {
		return "processform";
	}
	
	@RequestMapping("/processDataVersion1")
	public String processData(HttpServletRequest request,Model model) {
		String parameter = request.getParameter("name");
		String upperCase = parameter.toUpperCase();
		model.addAttribute("name",upperCase);
		return "HelloFile";
	}
}
