package com.spring.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;

@Controller
public class MyController {
	
	@RequestMapping("/")
	public String home() {
		return "home";
	}
	
	@RequestMapping("/showform")
	public String show() {
		return "form";
	}
	
	@RequestMapping("/processform")
	public String process() {
		return "processform";
	}
}
